# Tutorial privado: Docker, workflows y Oracle Container Registry (OCIR)

**Uso:** notas operativas locales. Esta carpeta (`docs/private/`) está en `.gitignore` y **no se sube** al repositorio remoto.

**No commitear:** Auth Tokens de OCI, namespaces completos si preferís no publicarlos, ni rutas internas sensibles.

---

## 1. Qué es qué

| Pieza | Rol |
|--------|-----|
| **Imagen Docker** | Incluye solo el motor (`francis_suite/`, dependencias). **No** incluye XML de workflows. |
| **Carpeta montada `workflows/`** | Los `.xml` viven en el host; en el contenedor aparecen en `/app/workflows`. |
| **`docker-output/`** | Volumen de salida (`./docker-output` → `/app/output` en el contenedor). |
| **Repositorio aparte `francis-workflows`** | Solo XML; se monta con `WORKFLOWS_HOST_PATH`. |
| **OCIR** | Registry en Oracle Cloud para **subir** la imagen; la VM hace `docker pull` después. |

---

## 2. Docker en local (francis-suite)

Desde la raíz del repo:

```powershell
cd C:\Users\mange\Desktop\francis-suite
docker compose build
```

**Workflow por defecto:** `./workflows` → `/app/workflows`.

**Otro directorio de workflows** (ej. clon de `francis-workflows`):

1. Copiar `.env.example` → `.env` en la **raíz de francis-suite** (no dentro de `.venv`).
2. Ejemplo:

   ```env
   WORKFLOWS_HOST_PATH=C:/Users/tu_usuario/Desktop/francis-workflows
   ```

3. Si el XML está en subcarpeta, el path del run incluye esa ruta:

   ```text
   workflows/examples-workflows/all_books_pages.xml
   ```

**Corrida con parámetros de auditoría:**

```powershell
$ingestionId = [guid]::NewGuid().ToString()
$runUtc = (Get-Date).ToUniversalTime().ToString("yyyyMMddTHHmmssZ")
$short = ([guid]::NewGuid().ToString().Replace("-", "")).Substring(0, 8)
docker compose run --rm francis francis-suite run workflows/examples-workflows/all_books_pages.xml `
  --param "ingestion_run_id=$ingestionId" `
  --param "run_utc=$runUtc" `
  --param "run_short_id=$short" `
  --param source=books_toscrape
```

(Ajustá la ruta del XML según tu árbol.)

**Salida:** `docker-output\<CARPETA_RUN>\` con `LISTINGS_*.NDJSON`, `RUN_MANIFEST.JSON`, `BOOKSRECORDS_PRIVATE_METADATA_*.JSON`, etc.

**Rebuild de imagen** cuando cambie código en `francis_suite/` o dependencias en `pyproject.toml` / `uv.lock`. **No** hace falta rebuild solo por cambiar XML montado.

---

## 3. Git en dos repos

- **`francis-suite`:** motor, Dockerfile, `examples/`, `workflows/` de ejemplo.
- **`francis-workflows`:** XML de producción. `git add .` y `git commit` **siempre desde la carpeta del repo** correspondiente (no mezclar en un solo `git` desde un padre).

---

## 4. Oracle: repositorio en OCIR

1. Consola: **Developer Services → Container Registry**.
2. Región (ej. **Santiago**): `sa-santiago-1`.
3. **Crear repositorio** (ej. `francis-suite`). Vacío hasta el primer `docker push` — es normal.

**Datos que necesitás:**

- **Registry host:** `sa-santiago-1.ocir.io` (para Santiago).
- **Namespace del tenancy:** *Administration → Tenancy → Object storage namespace* (string corto).
- **Usuario Docker:** `NAMESPACE/tu_usuario_OCI` (el usuario suele ser el correo con el que entrás a la consola).
- **Auth Token:** *User settings → Auth tokens → Generate* (copiar una sola vez; no es la contraseña de la cuenta Oracle).

---

## 5. Login `docker` en OCIR (PowerShell)

```powershell
$u = "NAMESPACE/tu_usuario"
$t = "PEGAR_AUTH_TOKEN"
echo $t | docker login sa-santiago-1.ocir.io -u $u --password-stdin
```

Esperar: `Login Succeeded`.

---

## 6. Tag y push (primera vez y siguientes)

Sustituir `NAMESPACE`, `REPO` y `TAG` por tus valores reales:

```powershell
$NS = "NAMESPACE"
$REPO = "francis-suite"
$TAG = "1.0.0"
$REG = "sa-santiago-1.ocir.io"

cd C:\Users\mange\Desktop\francis-suite
docker compose build
docker tag francis-suite:local "${REG}/${NS}/${REPO}:${TAG}"
docker push "${REG}/${NS}/${REPO}:${TAG}"
```

Comprobar que el tag local existe antes del push:

```powershell
docker images | Select-String "francis-suite"
```

**Errores comunes**

- **Tag no existe:** falta `docker tag` o el nombre no coincide con `docker images`.
- **Repo distinto:** el nombre en OCIR debe ser el mismo que `$REPO` en la ruta.
- **Login:** usuario sin `NAMESPACE/` delante, o token incorrecto.

---

## 7. Actualizar una versión nueva del motor

1. Cambios en código → `git push` en `francis-suite`.
2. En tu PC: `docker compose build`.
3. Nuevo tag (ej. `1.0.1` o `2026-04-02`):

   ```powershell
   docker tag francis-suite:local sa-santiago-1.ocir.io/NAMESPACE/francis-suite:1.0.1
   docker push sa-santiago-1.ocir.io/NAMESPACE/francis-suite:1.0.1
   ```

4. En la VM (cuando exista): `docker pull` de esa tag y actualizar el `image:` en compose o script.

**Solo XML** en `francis-workflows`: `git pull` en la carpeta montada; **sin** nueva imagen.

---

## 8. VM en OCI — conectar imagen + workflows + salida

**Idea:** en la VM solo necesitás **Docker**, el **clon de `francis-workflows`**, y el archivo **`docker-compose.ocir.yml`** del repo francis-suite + **`.env`**.

### 8.1 Crear la VM (OCI)

- **Compute → Instances → Create** (Ubuntu u Oracle Linux; tamaño pequeño alcanza para probar).
- **Red:** salida a Internet (scrape + `docker pull`).
- **Security list:** SSH **22** desde tu IP.

### 8.2 En la VM (SSH)

```bash
sudo apt update && sudo apt install -y docker.io docker-compose-plugin git
sudo usermod -aG docker $USER
```

Cerrá sesión SSH y volvé a entrar para que aplique el grupo `docker`.

### 8.3 Clonar workflows y carpeta de trabajo

```bash
mkdir -p ~/francis-run && cd ~/francis-run
git clone https://github.com/TU_USUARIO/francis-workflows.git
```

Copiá aquí **`docker-compose.ocir.yml`** desde el repo francis-suite (o descargalo desde GitHub raw).

### 8.4 `.env` en la VM

```env
FRANCIS_IMAGE=sa-santiago-1.ocir.io/TU_NAMESPACE/francis-suite:1.0.0
WORKFLOWS_HOST_PATH=/home/opc/francis-run/francis-workflows
```

(Ajustá ruta absoluta al clon y usuario de Linux.)

### 8.5 Login OCIR y pull

```bash
echo "AUTH_TOKEN" | docker login sa-santiago-1.ocir.io -u "NAMESPACE/USUARIO" --password-stdin
docker compose -f docker-compose.ocir.yml --env-file .env pull
```

### 8.6 Ejecutar un workflow

```bash
docker compose -f docker-compose.ocir.yml --env-file .env run --rm francis \
  francis-suite run workflows/examples-workflows/all_books_pages.xml
```

(Añadí `--param` como en local si querés auditoría.)

Salida en **`./docker-output`** junto al `docker-compose.ocir.yml`.

### 8.7 Estacion inmobiliaria (siguiente capa)

Subir artefactos a **Object Storage** o sincronizar `docker-output/`; el job de ingesta en **Supabase** lee **NDJSON** + **RUN_MANIFEST** según implementes en ese repo. No va dentro del contenedor Francis.

---

## 9. Recordatorio rápido del ejemplo `all_books_pages`

- Carpeta de corrida: `output/{SOURCE}_{UTC}_{SHORT}/` (en Docker: bajo `docker-output/`).
- Ingest típico: `LISTINGS_<SHORT>.NDJSON` + `RUN_MANIFEST.JSON`.
- `<record-save-metadata>` escribe en sesión **terminada** (metadata final con `status` `completed`).

---

## 10. Tests

En Windows, si `pytest` está bloqueado por políticas:

```powershell
uv run python -m pytest -q
```

---

*Última revisión: documento privado local; no versionado en git remoto.*
